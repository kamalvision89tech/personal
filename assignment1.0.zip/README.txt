Please make sure that nodejs(v6.11.2 or above) has installed in system:
-----------------------------------------------------------------------

Steps to deploy:
----------------

1. Navigate ./assignment folder
2. Open Cmd => run => npm run dev
3. Wait for some time to install all dependancies.
4. Open http://localhost:8080/
5. Import issue.CSV file
6. Check filter by count number value only.
